import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;


@Test
public class StringManipulaterTest {
	
	private StringManipulater stringManipulater;
	
	
	@BeforeTest
	public void init()
	{
		stringManipulater = new StringManipulater();
	}
	
	public void emptyStringReturnZero() throws Exception
	{
		assertEquals(stringManipulater.calculate(""), 0);
	}

	public void singleValueIsReturned() throws Exception {
		assertEquals(stringManipulater.calculate("1"), 1);
	}
	
	public void twoNumbersCommaDelimeterSum() throws Exception
	{
		assertEquals(stringManipulater.calculate("3,2"), 5);
	}
	
	public void twoNumberDelimetedReturnSum() throws Exception
	{
		assertEquals(stringManipulater.calculate("3\n5"), 8);
	}
	
	public void threeNumberDelimetedReturnSum() throws Exception
	{
		assertEquals(stringManipulater.calculate("1\n4,3"), 8);
	}
	
	public void threeNumbersDifferentDelimetedReturnSum() 
	{
		assertEquals(stringManipulater.sumFromDelimiterString("//;\n5;2"), 7);
	}
	
	@Test(expectedExceptions = Exception.class)
	public void negativeInputReturnException() throws Exception
	{
		stringManipulater.calculate("-1");
	}
	
	public void ignoreNumberGreaterThanOneThousand() throws Exception
	{
		assertEquals(stringManipulater.calculate("30,20,1001"), 50);
	}
	
	public void sumOfNumberFromAnyLengthDelimetedReturnSum()
	{
		assertEquals(stringManipulater.sumFromDelimiterString("//***\\n1***2***3"), 6);
	}
	
	public void sumOfNumberFromDifferentDelimeters()
	{
		assertEquals(stringManipulater.sumFromDelimiterString("//*|%\\n2*2%3"), 7);
	}
}
