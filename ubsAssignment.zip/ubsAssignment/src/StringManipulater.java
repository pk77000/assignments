/**
 * 
 */

/**
 * @author Prashant
 *
 */
public class StringManipulater {

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	public int calculate(String input) throws Exception {
	
		
		final String delimiters =  ",|\n";
		String[] numbers = input.split(delimiters);
		if (isEmpty(input)) {
			return 0;	
		}
		
		else if(input.length() == 1)
		{
			return convertStrToInt(input);
		}
		else
		{
			return getSum(numbers);
		}
		
	}
	
	private int getSum(String [] numbers) throws Exception 
	{
		
		checkNegativeNumbers(numbers);
		return calculateValue(numbers);
		
	}
	
	private int calculateValue(String [] numbers)throws Exception
    {
	 
        int sum =0;
		
		for (String str : numbers)
		{
			if (convertStrToInt(str)>1000)
			{
				continue;
			}
			sum += convertStrToInt(str);
		}
		return sum;
    }

	private void checkNegativeNumbers(String [] numbers)throws Exception
	{
		for (String str: numbers)
		{
			if (convertStrToInt(str)<0)
				throw new Exception ("negatives not allowed");
		}
	}
	
	private boolean isEmpty(String input)
	{
		return input.isEmpty();
	}
	
	private int convertStrToInt(String input) {
		
		return Integer.parseInt(input);
	}
	
	public int sumFromDelimiterString(String input){
	       int sum = 0;
	        for(int i = 0; i < input.length() ; i++){
	            if( Character.isDigit(input.charAt(i)) ){
	                sum = sum + Character.getNumericValue(input.charAt(i));
	            }
	        }
	        return sum;
	}

}
