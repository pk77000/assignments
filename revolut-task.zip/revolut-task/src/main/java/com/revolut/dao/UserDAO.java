package com.revolut.dao;

import com.revolut.exception.CustomException;
import com.revolut.model.User;

import java.util.List;

public interface UserDAO {
	

	User getUserByName(String userName) throws CustomException;

	List<User> getAllUsers() throws CustomException;

	User getUserById(long userId) throws CustomException;
	
	long insertUser(User user) throws CustomException;

	int updateUser(Long userId, User user) throws CustomException;

	int deleteUser(long userId) throws CustomException;

}
