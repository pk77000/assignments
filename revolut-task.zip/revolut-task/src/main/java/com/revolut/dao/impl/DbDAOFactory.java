package com.revolut.dao.impl;

import com.revolut.dao.AccountDAO;
import com.revolut.dao.DAOFactory;
import com.revolut.dao.UserDAO;
import com.revolut.dao.impl.AccountDAOImpl;
import com.revolut.dao.impl.UserDAOImpl;
import com.revolut.utils.Utils;

import org.apache.commons.dbutils.DbUtils;
import org.apache.log4j.Logger;
import org.h2.tools.RunScript;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * H2 DAO
 */
public class DbDAOFactory extends DAOFactory {
	private static final String h2_driver = Utils.getProperty("h2_driver");
	private static final String h2_connection_url = Utils.getProperty("h2_connection_url");
	private static final String h2_user = Utils.getProperty("h2_user");
	private static final String h2_password = Utils.getProperty("h2_password");
	private static Logger log = Logger.getLogger(DbDAOFactory.class);

	private final UserDAOImpl userDAO = new UserDAOImpl();
	private final AccountDAOImpl accountDAO = new AccountDAOImpl();

	public DbDAOFactory() {
		// init: load driver
		DbUtils.loadDriver(h2_driver);
	}

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(h2_connection_url, h2_user, h2_password);

	}

	public UserDAO getUserDAO() {
		return userDAO;
	}

	public AccountDAO getAccountDAO() {
		return accountDAO;
	}

	public void generateTestData() {
		log.info("Generating Test User Table and data ..... ");
		Connection conn = null;
		try {
			conn = DbDAOFactory.getConnection();
			RunScript.execute(conn, new FileReader("src/test/resources/testData.sql"));
		} catch (SQLException e) {
			log.error("generateTestData(): Error populating user data: ", e);
			throw new RuntimeException(e);
		} catch (FileNotFoundException e) {
			log.error("generateTestData(): Error finding test script file ", e);
			throw new RuntimeException(e);
		} finally {
			DbUtils.closeQuietly(conn);
		}
	}

}
