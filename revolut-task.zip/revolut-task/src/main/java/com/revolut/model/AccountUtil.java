package com.revolut.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;

import org.apache.log4j.Logger;

/**
 * Utilities class to operate on money
 */
public enum AccountUtil {

	INSTANCE;

	static Logger log = Logger.getLogger(AccountUtil.class);

	public static final BigDecimal zeroAmount = new BigDecimal(0).setScale(4, RoundingMode.HALF_EVEN);

	public boolean validateCcyCode(String inputCcyCode) {
		try {
			Currency instance = Currency.getInstance(inputCcyCode);
			if (log.isDebugEnabled()) {
				log.debug("Validate Currency Code: " + instance.getSymbol());
			}
			return instance.getCurrencyCode().equals(inputCcyCode);
		} catch (Exception e) {
			log.warn("Cannot parse the input Currency Code, Validation Failed: ", e);
		}
		return false;
	}

}
