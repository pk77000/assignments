package com.creditSsuisse.assignment;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
 import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.json.JSONException;
import org.json.JSONObject;

 public class AssignmentSolution {

	private static ConcurrentMap<String, ServerEvent> eventsFromFile = new ConcurrentHashMap<>();
	private static int cpuCount = Runtime.getRuntime().availableProcessors();
	private final static ArrayBlockingQueue<String>[] idQueue = new ArrayBlockingQueue[cpuCount];
	private static Connection conn;
	private static Statement stmt = null;
	private static int dbCounter = 0;
	private static Thread readerThread = null;
	private static ExecutorService executor = null;
 	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		String inputFilePath = new String();
		System.out.print("Enter the json input file with correct path:");
		inputFilePath = scanner.nextLine();
		File inputFile = new File(inputFilePath);
		if (!inputFile.exists()) {
			System.out.println("Json file does not exist.");
			System.exit(1);
		}
		//writer = new BufferedWriter(new FileWriter("output.sql"));
		for (int i = 0; i < idQueue.length; i++) {
			idQueue[i] = new ArrayBlockingQueue<>(cpuCount * 1000);
		}
		executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		fileReader(inputFile);
 	}
 	
 	private static void fileReader(File inputFile) throws Exception {
		Runnable task = () -> {
			LineIterator it = null;
			try {
				it = FileUtils.lineIterator(inputFile, "UTF-8");
			} catch (IOException e) {
				e.printStackTrace();
			}
			long lineCounter = 0;
			while (it.hasNext()) {
				String line = it.nextLine();
				JSONObject jo;
				try {
					jo = new JSONObject(line);
				
				ServerEvent serverEvent = null;
				if (jo.has("type")) {
					serverEvent = new ServerEvent(jo.getString("id"), jo.getString("state"), jo.getLong("timestamp"),
							jo.getString("type"), jo.getString("host"),null);
				}
				else {
					serverEvent = new ServerEvent(jo.getString("id"), jo.getString("state"), jo.getLong("timestamp"), null,
							null, null);
				}
 				eventsFromFile.put(serverEvent.getId() + serverEvent.getState(), serverEvent);
				idQueue[(int) (lineCounter%cpuCount)].offer(serverEvent.getId());
				} catch (JSONException e1) {
					e1.printStackTrace();
				}
				if (lineCounter++ % 10000 == 0) {
					try {
						insertDb();
					} catch (Exception e) {
					}
				}
 			}
		};
 		readerThread = new Thread(task);
		readerThread.start();
 	}
 	
 	private static void dbConnection() {
	      try {
		         Class.forName("org.hsqldb.jdbc.JDBCDriver");
		         conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/testdb", "SA", "");
		         if (conn!= null){
		            System.out.println("Connection created successfully");
		            
		         }else{
		            System.out.println("Problem with creating connection");
		         }
		      
		      }
		catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
 	
 	private static void insertDb() throws Exception {
		Runnable task = () -> {
			  int result = 0;
			  dbConnection(); 
			  try {
			  stmt = conn.createStatement();
			  
			  stmt.execute("SET FILES LOG FALSE;DROP TABLE eventtest IF EXISTS;\n" +
			  "CREATE TABLE IF NOT EXISTS eventtest (\n" + "    id VARCHAR(50) NOT NULL,\n" +
			  "    duration BIGINT,\n" +
			  "    type VARCHAR(50),\n" + "    host VARCHAR(50),\n" + "     alert BOOLEAN,\n" + " PRIMARY KEY (id)\n"
			  + ");\n");
			  conn.commit();  
			  } catch (Exception e) {
			  } 
			 
			long lineCounter = 0;
			int threadId = (int) Thread.currentThread().getId()%cpuCount;
			while (idQueue[threadId].size() > 0) {
				String id = idQueue[threadId].poll();
				ServerEvent serverEventStarted = eventsFromFile.get(id + "STARTED");
				ServerEvent serverEventFinished = eventsFromFile.get(id + "FINISHED");
 				if (serverEventFinished != null && serverEventStarted != null) {
					long diffTime = Math.abs(serverEventFinished.getTimestamp() - serverEventStarted.getTimestamp());
					if (diffTime > 4) {
						serverEventStarted.setAlert(true);
						serverEventFinished.setAlert(true);
						serverEventFinished.setDuration(diffTime);
					}
					
			         try {
						result = stmt.executeUpdate("INSERT INTO eventtest(id,duration,type,host,alert) VALUES ('" + serverEventFinished.getId()
						 + "'," + serverEventFinished.getDuration() + ",'" + serverEventFinished.getType() + "','" + serverEventFinished.getHost() + "'," + serverEventFinished.getAlert()
						+ ");");
						conn.commit();
					} catch (SQLException e) {
						e.printStackTrace();
					} 
					eventsFromFile.remove(serverEventStarted.getId() + serverEventStarted.getState());
					eventsFromFile.remove(serverEventFinished.getId() + serverEventFinished.getState());
 				}
 			}
		};
		executor.execute(task);
	}
 	
}