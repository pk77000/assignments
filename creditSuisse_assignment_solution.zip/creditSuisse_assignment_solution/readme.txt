*** The solution ***

__Description__

This project developed using java 8 programming language and hsqldb.
There are three java files in this project:

1. ServerEvent.java - It is bean(pojo) file, contain setter and getter method.

2. AssignmentSolution.java - Below are the methods contain in this file:

2.1 private static void fileReader(File inputFile) throws Exception  -
This method takes a json file from argument and read the file line by line
and line passed to JSONObject() then if and else confition and finally put in 
concurrentHashMap - id + state as a key and pojo object (EventServer) as a value
and finally called  insertDb() method.  

2.2 private static void insertDb() throws Exception  -
This method will used to create table eventtest and insert data in table.
2.3 private static void dbConnection() - This method is used
to establish connection with database - testdb.

3. SelectQuery.java - user can see the inserted data in table after run this file.

---------------------------------------------------------------------
how to run this application
----------------------------

run the file AssignmentSolution.java, it will asked in argument that 
Enter the json input file with correct path: 
user need to enter input.txt file (attached in this project) after that program 
will do read opration of input file and put data in table as per condition 
mentioned in assignment(pdf).
longer than 4ms will be stored in column - duration
and I put those data in columns (id,duration,type,host,alert). output screenshot
attached in this project.

Note : Java - CS-DTS-CodingAssignment-20180719.pdf file having an error in line:
 In the example above, the event scsmbstgrb duration is 1401377495216 - 1491377495213 = 3ms 
 here 1401377495216 should be 1491377495216. 
I did not used gradle because time constraint.

Thank you.

